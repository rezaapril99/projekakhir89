<?php
function rubah($pilihan)
{
  if($pilihan==0)
  {
    $tanda="-";
  }
  else
  {
    $tanda="&radic;";
  }
  return $tanda;
}